"""Project configuration with deliberately small, explicit defaults."""

from __future__ import annotations

from dataclasses import dataclass, field
import json
import os
from pathlib import Path
import re
import stat
import tomllib
from types import MappingProxyType
from typing import Mapping
from uuid import uuid4

from .contracts import ContractError, validate_named
from .identifiers import IdentifierError, require_identifier
from .jira_sync import JiraSyncError, JiraSyncPolicy
from .model_policy import MODEL_TIERS, REASONING_EFFORTS

CONFIG_DIRECTORY = ".tasktra"
CONFIG_FILENAME = "project.toml"
DEFAULT_DATABASE = ".tasktra/runtime/tasktra.sqlite"


class ConfigError(ValueError):
    """Raised when a Tasktra project configuration is invalid."""


@dataclass(frozen=True)
class ProjectRoute:
    identifier: str
    trigger: str
    role: str | None = None
    skills: tuple[str, ...] = ()
    boundary: str | None = None
    roles: tuple[str, ...] = ()


@dataclass(frozen=True)
class ProjectConfig:
    name: str
    version: int = 1
    database: str = DEFAULT_DATABASE
    enabled_packs: tuple[str, ...] = ("core",)
    validation_commands: tuple[tuple[str, ...], ...] = ()
    include_pack_validation_defaults: bool = True
    concurrency_limit: int = 3
    catalog_trusted: bool = False
    codex_tier_models: Mapping[str, str] = field(default_factory=dict)
    codex_role_overrides: Mapping[str, Mapping[str, str]] = field(default_factory=dict)
    routes: tuple[ProjectRoute, ...] = ()
    jira_sync: JiraSyncPolicy | None = None
    raw: dict = field(default_factory=dict, compare=False, repr=False)

    def database_path(self, root: Path) -> Path:
        project = root.resolve()
        candidate = Path(self.database)
        lexical = candidate if candidate.is_absolute() else project / candidate
        try:
            lexical_absolute = Path(os.path.abspath(lexical))
            lexical_relative = lexical_absolute.relative_to(project)
        except (OSError, ValueError) as error:
            raise ConfigError("runtime.database must resolve inside the project root") from error
        current = project
        for part in lexical_relative.parts:
            current = current / part
            if _is_linklike(current):
                raise ConfigError(f"runtime.database crosses a symbolic link or reparse point: {current}")
        try:
            resolved = lexical_absolute.resolve(strict=False)
            resolved.relative_to(project)
        except (OSError, ValueError) as error:
            raise ConfigError("runtime.database must resolve inside the project root") from error
        return resolved


def config_path(root: Path) -> Path:
    return root / CONFIG_DIRECTORY / CONFIG_FILENAME


def _is_linklike(path: Path) -> bool:
    is_junction = getattr(path, "is_junction", None)
    if path.is_symlink() or bool(is_junction and is_junction()):
        return True
    try:
        attributes = os.stat(path, follow_symlinks=False).st_file_attributes
    except (AttributeError, OSError):
        return False
    return bool(attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT)


def default_config_text(name: str) -> str:
    # JSON and TOML share these escapes, except TOML also forbids literal DEL.
    safe_name = json.dumps(name or "tasktra-project", ensure_ascii=False).replace("\x7f", "\\u007f")
    return f'''# Tasktra project profile. Project-owned settings belong here.
[project]
name = {safe_name}
config_version = 1

[runtime]
database = ".tasktra/runtime/tasktra.sqlite"
concurrency_limit = 3

[packs]
enabled = ["core"]

[catalog]
trust_builtin = false

[validation]
include_pack_defaults = true
commands = []
'''


def initialize_project(root: Path, *, name: str | None = None) -> Path:
    """Create only the project definition; never overwrite an existing one."""
    if _is_linklike(root):
        raise ConfigError("project root crosses a symbolic link or reparse point")
    project = root.resolve(strict=False)
    root.mkdir(parents=True, exist_ok=True)
    destination = config_path(root)

    def check_destination() -> None:
        for path in (root, destination.parent, destination):
            if _is_linklike(path):
                raise ConfigError(f"configuration crosses a symbolic link or reparse point: {path}")
        if destination.parent.resolve(strict=False).parent != project:
            raise ConfigError("configuration must remain inside the project root")
        if destination.exists():
            raise FileExistsError(f"Tasktra configuration already exists: {destination}")

    check_destination()
    destination.parent.mkdir(exist_ok=True)
    check_destination()
    temporary = destination.with_name(f".{CONFIG_FILENAME}.{uuid4().hex}.tmp")
    try:
        with temporary.open("x", encoding="utf-8", newline="\n") as handle:
            handle.write(default_config_text(name or root.name))
            handle.flush()
            os.fsync(handle.fileno())
        check_destination()
        # Publish complete bytes without replacing a profile created concurrently.
        os.link(temporary, destination)
    finally:
        if not _is_linklike(destination.parent):
            temporary.unlink(missing_ok=True)
    return destination


def _table(value: object, name: str) -> dict:
    if not isinstance(value, dict):
        raise ConfigError(f"[{name}] must be a table")
    return value


def _string_list(value: object, name: str) -> tuple[str, ...]:
    if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
        raise ConfigError(f"{name} must be a list of strings")
    return tuple(value)


def _argv_list(value: object, name: str) -> tuple[tuple[str, ...], ...]:
    if not isinstance(value, list):
        raise ConfigError(f"{name} must be a list of argv arrays, not shell command strings")
    argv: list[tuple[str, ...]] = []
    for index, command in enumerate(value):
        if isinstance(command, str):
            raise ConfigError(
                f"{name}[{index}] must be an argv array, not a string; "
                'use ["python", "-m", "unittest"]'
            )
        if not isinstance(command, list) or not command or not all(isinstance(item, str) and item for item in command):
            raise ConfigError(f"{name}[{index}] must be a non-empty argv array of strings")
        if any("\x00" in item for item in command):
            raise ConfigError(f"{name}[{index}] argv items must not contain NUL bytes")
        argv.append(tuple(command))
    return tuple(argv)


def _codex_agents(value: object) -> tuple[Mapping[str, str], Mapping[str, Mapping[str, str]]]:
    agents = _table(value, "agents") if value else {}
    if set(agents) - {"codex"}:
        raise ConfigError("agents permits only the codex table")
    codex = _table(agents.get("codex", {}), "agents.codex")
    if set(codex) - {"model_tiers", "roles"}:
        raise ConfigError("agents.codex permits only model_tiers and roles")
    tiers = _table(codex.get("model_tiers", {}), "agents.codex.model_tiers")
    parsed_tiers: dict[str, str] = {}
    for tier, model in tiers.items():
        if tier not in MODEL_TIERS:
            raise ConfigError(f"agents.codex.model_tiers has unknown tier: {tier}")
        if not isinstance(model, str) or not model.strip() or model == "inherit":
            raise ConfigError(f"agents.codex.model_tiers.{tier} must be a non-empty model id")
        parsed_tiers[tier] = model
    roles = _table(codex.get("roles", {}), "agents.codex.roles")
    parsed_roles: dict[str, Mapping[str, str]] = {}
    for role, override in roles.items():
        try:
            require_identifier(role, label="agents.codex role")
        except IdentifierError as error:
            raise ConfigError(str(error)) from error
        override = _table(override, f"agents.codex.roles.{role}")
        if not override or set(override) - {"model", "reasoning_effort"}:
            raise ConfigError(f"agents.codex.roles.{role} permits only non-empty model/reasoning_effort overrides")
        parsed: dict[str, str] = {}
        if "model" in override:
            model = override["model"]
            if not isinstance(model, str) or not model.strip():
                raise ConfigError(f"agents.codex.roles.{role}.model must be a non-empty model id or inherit")
            parsed["model"] = model
        if "reasoning_effort" in override:
            effort = override["reasoning_effort"]
            if not isinstance(effort, str) or effort not in REASONING_EFFORTS | {"inherit"}:
                raise ConfigError(f"agents.codex.roles.{role}.reasoning_effort is invalid")
            parsed["reasoning_effort"] = effort
        parsed_roles[role] = MappingProxyType(parsed)
    return MappingProxyType(parsed_tiers), MappingProxyType(parsed_roles)


def _routes(value: object) -> tuple[ProjectRoute, ...]:
    routing = _table(value, "routing") if value else {}
    entries = routing.get("routes", [])
    routes: list[ProjectRoute] = []
    identifiers: set[str] = set()
    triggers: set[str] = set()
    for index, entry in enumerate(entries):
        identifier = entry["id"]
        try:
            require_identifier(identifier, label=f"routing.routes[{index}].id")
        except IdentifierError as error:
            raise ConfigError(str(error)) from error
        trigger = entry["trigger"].strip()
        role = entry.get("role")
        roles = tuple(entry.get("roles", []))
        skills = tuple(entry.get("skills", []))
        boundary = entry.get("boundary")
        if not trigger or "\n" in trigger or "\r" in trigger:
            raise ConfigError(f"routing.routes[{index}].trigger must be one non-empty line")
        if boundary is not None and (not boundary.strip() or "\n" in boundary or "\r" in boundary):
            raise ConfigError(f"routing.routes[{index}].boundary must be one non-empty line")
        if role is not None and roles:
            raise ConfigError(f"routing.routes[{index}] permits role or roles, not both")
        if role is None and not roles and not skills:
            raise ConfigError(f"routing.routes[{index}] needs a role or skill")
        for selected_role in ((role,) if role is not None else roles):
            try:
                require_identifier(selected_role, label=f"routing.routes[{index}].role")
            except IdentifierError as error:
                raise ConfigError(str(error)) from error
        if len({selected_role.casefold() for selected_role in roles}) != len(roles):
            raise ConfigError(f"routing.routes[{index}].roles contains duplicates")
        if any(re.fullmatch(r"[a-z0-9][a-z0-9._:-]*", skill) is None for skill in skills):
            raise ConfigError(f"routing.routes[{index}].skills contains an invalid name")
        if len({skill.casefold() for skill in skills}) != len(skills):
            raise ConfigError(f"routing.routes[{index}].skills contains duplicates")
        if identifier.casefold() in identifiers:
            raise ConfigError(f"duplicate route id: {identifier}")
        if trigger.casefold() in triggers:
            raise ConfigError(f"duplicate route trigger: {trigger}")
        identifiers.add(identifier.casefold())
        triggers.add(trigger.casefold())
        routes.append(ProjectRoute(identifier, trigger, role, skills, boundary.strip() if boundary else None, roles))
    return tuple(routes)


def load_project_config(root: Path) -> ProjectConfig:
    path = config_path(root)
    if not path.is_file():
        raise FileNotFoundError(f"No Tasktra configuration at {path}")
    try:
        data = tomllib.loads(path.read_text(encoding="utf-8"))
    except tomllib.TOMLDecodeError as error:
        raise ConfigError(f"Invalid TOML in {path}: {error}") from error
    validation_raw = data.get("validation", {})
    if isinstance(validation_raw, dict) and "commands" in validation_raw:
        # Keep this diagnostic clear even though the JSON contract also rejects
        # legacy strings.
        _argv_list(validation_raw["commands"], "validation.commands")
    try:
        validate_named(data, "project")
    except ContractError as error:
        raise ConfigError(str(error)) from error
    project = _table(data.get("project"), "project")
    runtime = _table(data.get("runtime", {}), "runtime")
    packs = _table(data.get("packs", {}), "packs")
    catalog = _table(data.get("catalog", {}), "catalog")
    validation = _table(data.get("validation", {}), "validation")
    jira_sync_raw = data.get("jira_sync")
    tier_models, role_overrides = _codex_agents(data.get("agents", {}))
    routes = _routes(data.get("routing", {}))
    name = project.get("name")
    version = project.get("config_version", 1)
    database = runtime.get("database", DEFAULT_DATABASE)
    concurrency = runtime.get("concurrency_limit", 3)
    catalog_trusted = catalog.get("trust_builtin", False)
    include_pack_defaults = validation.get("include_pack_defaults", True)
    if not isinstance(name, str) or not name.strip():
        raise ConfigError("project.name must be a non-empty string")
    if not isinstance(version, int) or version != 1:
        raise ConfigError("project.config_version must be 1")
    if not isinstance(database, str) or not database.strip():
        raise ConfigError("runtime.database must be a non-empty string")
    if not isinstance(concurrency, int) or concurrency < 1:
        raise ConfigError("runtime.concurrency_limit must be a positive integer")
    if not isinstance(catalog_trusted, bool):
        raise ConfigError("catalog.trust_builtin must be boolean")
    if not isinstance(include_pack_defaults, bool):
        raise ConfigError("validation.include_pack_defaults must be boolean")
    jira_sync = None
    if jira_sync_raw is not None:
        if "jira-sync" not in _string_list(packs.get("enabled", ["core"]), "packs.enabled"):
            raise ConfigError("[jira_sync] requires the optional jira-sync pack")
        try:
            jira_sync = JiraSyncPolicy.from_mapping(_table(jira_sync_raw, "jira_sync"))
        except JiraSyncError as error:
            raise ConfigError(str(error)) from error
    return ProjectConfig(
        name=name, version=version, database=database,
        enabled_packs=_string_list(packs.get("enabled", ["core"]), "packs.enabled"),
        validation_commands=_argv_list(validation.get("commands", []), "validation.commands"),
        include_pack_validation_defaults=include_pack_defaults,
        concurrency_limit=concurrency, raw=data,
        catalog_trusted=catalog_trusted,
        codex_tier_models=tier_models, codex_role_overrides=role_overrides,
        routes=routes,
        jira_sync=jira_sync,
    )
